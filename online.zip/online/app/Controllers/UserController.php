<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class UserController extends BaseController
{
    public function login()
    {
        return view('test/login.php');
    }

public function dashboard()
{
    return view('test/dashboard.php');
}
public function about()
{
    return view('test/about.php');
}
public function contact()
{
    return view('test/contact.php');
}
public function men()
{
    return view('test/men.php');
}
public function women()
{
    return view('test/women.php');
}
public function cart()
{
    return view('test/cart.php');
}
public function ordercomplete()
{
    return view('test/ordercomplete.php');
}
public function product()
{
    return view('test/product.php');
}
public function orderr()
{
    return view('test/orderr.php');
}


}
