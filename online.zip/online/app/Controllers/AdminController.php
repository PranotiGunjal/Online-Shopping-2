<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\Farmer;

class FarmerController extends BaseController
{ 
    
    private $farmer = '' ;
    public function __construct(){
      
        $this->farmer = new Farmer();       
    }
    public function index()
    {
        return view('agri/farms_add');
    }
    public function insert()
    {
        $data =['name' =>$this->request->getVar('name'),
        'surname' =>$this->request->getVar('surname'),
        'phone' =>$this->request->getVar('phone'),
        'region' =>$this->request->getVar('region'),];
       
        $model= new Farmer();
        $model->insert($data);
        //return redirect('agri/farms_add');
        return redirect()->to('/farms_add');
        
    }

    
    
     
    public function delete($id){

        $data['farmer'] = $this->farmer->where('id', $id)->delete($id);
        return $this->response->redirect(site_url('/farms_view'));
    
       }
}