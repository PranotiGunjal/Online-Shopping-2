<?php namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\Testers;

class TestersController extends BaseController
{

   public function index(){
      $testers = new Testers();

      ## Fetch all records
      $data['testers'] = $testers->findAll();
      return view('testers/index',$data);
   }

   public function create(){
      return view('testers/create');
   }

   public function store(){
      $request = service('request');
      $postData = $request->getPost();

      if(isset($postData['submit'])){

         ## Validation
         $input = $this->validate([
            'name' => 'required|min_length[2]',
            'mobno' => 'required|max_length[10]',
             
            'address' => 'required',
            
         ]);

         if (!$input) {
            return redirect()->route('testers/create')->withInput()->with('validation',$this->validator); 
         } else {

            $testers = new Testers();

            $data = [
               'name' => $postData['name'],
               'mobno' => $postData['mobno'],
                
               'address' => $postData['address'],
               
            ];

            ## Insert Record
            if($testers->insert($data)){
               session()->setFlashdata('message', 'Added Successfully!');
               session()->setFlashdata('alert-class', 'alert-success');

               return redirect()->route('testers/create'); 
            }else{
               session()->setFlashdata('message', 'Data not saved!');
               session()->setFlashdata('alert-class', 'alert-danger');

               return redirect()->route('testers/create')->withInput(); 
            }

         }
      }

   }

   public function edit($id = 0){

      ## Select record by id
      $testers = new Testers();
      $testers = $testers->find($id);

      $data['testers'] = $testers;
      return view('testers/edit',$data);

   }

   public function update($id = 0){
      $request = service('request');
      $postData = $request->getPost();

      if(isset($postData['submit'])){

        ## Validation
        $input = $this->validate([
          'name' => 'required|min_length[3]',
          'mobno' => 'required',
          
          'address' => 'required',
          
        ]);

        if (!$input) {
           return redirect()->route('testers/edit/'.$id)->withInput()->with('validation',$this->validator); 
        } else {

           $testers = new Testers();

           $data = [
              'name' => $postData['name'],
              'mobno' => $postData['mobno'],
               
               'address' => $postData['address'],
                
           ];

           ## Update record
           if($testers->update($id,$data)){
              session()->setFlashdata('message', 'Updated Successfully!');
              session()->setFlashdata('alert-class', 'alert-success');

              return redirect()->route('testers/index'); 
           }else{
              session()->setFlashdata('message', 'Data not saved!');
              session()->setFlashdata('alert-class', 'alert-danger');

              return redirect()->route('testers/edit/'.$id)->withInput(); 
           }

        }
      }

   }

   public function delete($id=0){

      $testers = new Testers();

      ## Check record
      if($testers->find($id)){

         ## Delete record
         $testers->delete($id);

         session()->setFlashdata('message', 'Deleted Successfully!');
         session()->setFlashdata('alert-class', 'alert-success');
      }else{
         session()->setFlashdata('message', 'Record not found!');
         session()->setFlashdata('alert-class', 'alert-danger');
      }

      return redirect()->route('testers/index');

   }
}