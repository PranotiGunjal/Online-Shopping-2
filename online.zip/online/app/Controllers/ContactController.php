<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\Contact;

class ContactController extends BaseController
{
    public function index()
    {
      
        return view('test/contact');
    }
    public function insert2()
    {
        $data =['firstname' =>$this->request->getVar('firstname'),
        'lastname' =>$this->request->getVar('lastname'),    
        'email_id' =>$this->request->getVar('email_id'),
        'subject' =>$this->request->getVar('subject'),
        'message' =>$this->request->getVar('message'),
         ];
      
        $model= new Contact();
        $model->insert($data);
        //return redirect('agri/farms_add');
        return redirect()->to('/contact');
        
    
    }
}
     