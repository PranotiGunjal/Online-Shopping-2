<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class RegistrationController extends BaseController
{
    public function registration()
    {
        // return view('test/login.php');   
        return view('test/registration.php');
    }
}
