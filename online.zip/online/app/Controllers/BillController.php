<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class BillController extends BaseController
{
    public function index()
    {
        //
    }
}
