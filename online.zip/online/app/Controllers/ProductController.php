<?php

namespace App\Controllers;
use App\Models\Product;
use App\Controllers\BaseController;

class ProductController extends BaseController
{
    public function index()
    {
        return view('test/product.php');
    }
    public function insert4()
    {
        $data =['product_id' =>$this->request->getVar('product_id'),
        'customer_id' =>$this->request->getVar('customer_id'),    
        'name' =>$this->request->getVar('name'),
        'price' =>$this->request->getVar('price'),
        'stock' =>$this->request->getVar('stock'),
         ];
      
        $model= new Product();
        $model->insert($data);
        //return redirect('agri/farms_add');
        return redirect()->to('/product');
        
    
    }
}
