<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\Orderr;

class OrderController extends BaseController
{
    public function index()
    {
        return view('test/order.php');
    }

    
    public function insert3()
    {
        $data =['firstname' =>$this->request->getVar('firstname'),
        'lastname' =>$this->request->getVar('lastname'),    
        'mobile_no' =>$this->request->getVar('mobile_no'),
        'email_id' =>$this->request->getVar('email_id'),
         ];
      
        $model= new Orderr();
        $model->insert($data);
        //return redirect('agri/farms_add');
        return redirect()->to('/orderr');
        
    
    }
}
     
    
