<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class CategoriesController extends BaseController
{
    public function index()
    {
        //
    }
}
