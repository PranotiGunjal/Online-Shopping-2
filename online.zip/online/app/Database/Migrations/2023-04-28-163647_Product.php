<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Product extends Migration
{
    public function up()
    {
        $this->forge->addfield([
            'product_id'=>[
            'type'=>'INT',
            'constraint'=>20,
            'unsigned'=>true,
            'auto_increament'=>true,  
        ],
            'customer_id'=>[
            'type'=>'INT',
            'constraint'=>40,
            'unsigned'=>true,
            'auto_increament'=>true,  
        ],
            'name'=>[
            'type'=>'VARCHAR',
            'constraint'=>'30',
        ],
            'price'=>[
            'type'=>'INT',
            'constraint'=>'50'
        ],
            'stock'=>[
            'type'=>'INT',
            
        ],
    ]);
          $this->forge->addkey('product_id',true);
          $this->forge->createTable('product');
            
      }

    public function down()
    {
        $this->forge->dropTable('product');
    }
}