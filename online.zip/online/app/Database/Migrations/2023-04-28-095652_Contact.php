<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Contact extends Migration
{
    public function up()
    {
        $this->forge->addfield([
        'firstname'=>[
            'type'=>'VARCHAR',
            'constraint'=>'30',
        ],
        'lastname'=>[
            'type'=>'VARCHAR',
            'constraint'=>'30',
        ],
        'email_id'=>[
            'type'=>'VARCHAR',
            'constraint'=>'40',
        ],
        'subject'=>[
            'type'=>'VARCHAR',
            'constraint'=>'40',
        ],
        'message'=>[
            'type'=>'VARCHAR',
            'constraint'=>'40',
        ],
    ]);
    $this->forge->addkey('id',true);
    $this->forge->createTable('contact');


    }

    public function down()
    {
        $this->forge->dropTable('contact');
    }
}
