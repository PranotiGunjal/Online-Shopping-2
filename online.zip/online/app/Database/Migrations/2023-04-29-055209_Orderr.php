<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Orderr extends Migration
{
    public function up()
    {
        $this->forge->addfield([
            'firstname'=>[
                'type'=>'VARCHAR',
                'constraint'=>'30',
            ],
            'lastname'=>[
                'type'=>'VARCHAR',
                'constraint'=>'30',
            ],
            'mobile_no'=>[
                'type'=>'INT',
                'constraint'=>'30',
            ],
            'email_id'=>[
                'type'=>'VARCHAR',
                'constraint'=>'40',
            ],
        ]);
        $this->forge->addkey('id',true);
        $this->forge->createTable('orderr');


    }

    public function down()
    {
        $this->forge->dropTable('orderr');
    }
}
