<html>
<head>
<title>Product</title>    
</head>
<body>
<center>
 <form action="<?php echo site_url('/insert3');?>" method="post">
<h1><b>ADD Product</b></h1>
Enter Product id:<br>
<input type="text" name="product_id"><br>

Enter Customer id:<br>
<input type="text" name="customer_id"><br>
Enter Product name:<br>
<input type="text" name="name"><br>
Enter Product price:<br>
<input type="textarea" name="price"><br>
Enter Product stock:<br>
<input type="textarea" name="stock"><br>
<input type="submit" name="submit" value="Add"><br>
</form>
</center>
</body>
</html>