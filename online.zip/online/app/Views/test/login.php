<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- custome css  -->
    <link rel="stylesheet" href="./style.css">
    <title>Registration</title>
</head>
<body>
    <style>

{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}
body
{
    font-family: "Open Sans",
    -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", Helvetica, Arial, sans-serif;
}
.main-parent
{
    width: 100%;
    height: 100vh;
    background-image: url("https://img.freepik.com/free-photo/fashion-shoes-sneaker_1203-8081.jpg");
    background-repeat: no-repeat;
    background-size: cover;
    background-position: top;
    display: flex;
    justify-content: center;
    align-items: center;
}
.main-parent .form-wrap
{
    width: 450px;
    background: rgb(255 255 255 / 75%);
    border-radius: 10px;
    padding: 35px 40px;
    backdrop-filter: blur(5px);
}
.form-wrap form h1
{
    font-family: 'Acme', sans-serif;
    font-variant: small-caps;
    font-size: 45px;
    text-align: center;
    margin-bottom: 15px;
}
.form-wrap form h1 span
{
    font-variant: small-caps;
    color: #f57224;
}
.form-wrap form .single-input input
{
    width: 100%;
    padding: 14px 10px;
    border: 1px solid rgba(0, 0, 0, 0.3521);
    outline: none;
    background: transparent;
    margin-bottom: 10px;
    font-size: 15px;
    font-family: 'Roboto', sans-serif;
}
.form-wrap form .submit-button
{
    text-align: center;
}
.form-wrap form .submit-button button.button
{
    padding: 13px 30px;
    background-color: #f57224;
    outline: none;
    border: none;
    color: #fff;
    font-family: 'Roboto', sans-serif;
    font-size: 16px;
    cursor: pointer;
}
.form-wrap form .account-have
{
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 14px;
    margin-top: 10px;
}
.form-wrap form .account-have a
{
    color: rgb(34, 34, 34);
    text-decoration: none;
}

        </style>
  
    <div class="main-parent">
        <div class="form-wrap">
            <form action="dashboard">
                <h1><span>Login</span>Form</h1>
                <div class="single-input">
                    <input id="emailAddress" type="email" placeholder="Email Address" required>
                </div>
                <div class="single-input">
                    <input id="passWord" type="password" placeholder="Password" required>
                </div>
                <div class="submit-button ">
                <a href="dashboard"><button class="button login"></a>Login</button>
                </div>
                <div class="account-have">
                    <a href="dashboard">Forget Password</a>
                    <a href="index.html">Create new account</a>
                </div>
            </form>
        </div>
    </div>
    <script src="./sweetalert.js"></script>
    <script src="./app.js"></script>
</body>
</html>