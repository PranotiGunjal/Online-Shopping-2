<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form method="post" >
  <div class="container">
    <h1>Register</h1>
    <p>Please fill in this form to create an account.</p>
    <hr>
    <label for="id"><b>ID</b></label>
    <input type="text" placeholder="Enter ID" name="admin_id" id="id" required><br><br>

    <label for="name"><b>name</b></label>
    <input type="text" placeholder="Enter name" name="name" id="name" required><br><br>

    <label for="mobno"><b>mobno</b></label>
    <input type="text" placeholder="Enter mobile no" name="mobile_no" id="mobno" required><br><br>

    <label for="email"><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="email_id" id="email" required><br><br>

    <label for="address"><b>Address</b></label>
    <input type="text" placeholder="Enter address" name="password" id="address" required><br><br>



    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="psw" id="psw" required><br><br>

    <label for="psw-repeat"><b>Repeat Password</b></label>
    <input type="password" placeholder="Repeat Password" name="psw-repeat" id="psw-repeat" required><br>
    <hr>

    <p>By creating an account you agree to our <a href="#">Terms & Privacy</a>.</p>
    <button type="submit" class="registerbtn" name="register">Register</button>
  </div>

  <div class="container signin">
    <p>Already have an account? <a href="#">Sign in</a>.</p>
  </div>
</form> 
</body>
</html>