<?= $this->extend('layouts2/layout') ?>

<?= $this->section('content') ?>

<div class="actionbutton mt-2">
   <a class="btn btn-info float-right mb20" href="<?=site_url('testers/create')?>">Add Product</a>
</div>

<?php 
// Display Response
if(session()->has('message')){
?>
   <div class="alert <?= session()->getFlashdata('alert-class') ?>">
      <?= session()->getFlashdata('message') ?>
   </div>
<?php
}
?>

<!-- Subject List -->
<table width="100%" border="1" style="border-collapse: collapse;">
  <thead>
    <tr>
      <th width="10%">ID</th>
      <th width="20%">Name</th>
      <th width="15%">Mobile No</th>
 
      <th width="20%">Address</th>
       
      <th width="20%">action</th>
    </tr>
  </thead>
  <tbody>
  <?php 
  if(count($testers) > 0){

    foreach($testers as $tester){
  ?>
     <tr>
       <td><?= $tester['id'] ?></td>
       <td><?= $tester['name'] ?></td>
       <td><?= $tester['mobno'] ?></td>
     
       <td><?= $tester['address'] ?></td>
        
       <td align="center">
         <a class="btn btn-sm btn-info" href="<?= site_url('testers/edit/'.$tester['id']) ?>">Edit</a>
         <a class="btn btn-sm btn-danger" href="<?= site_url('testers/delete/'.$tester['id']) ?>">Delete</a>
       </td>
     </tr>
  <?php
    }

  }else{
  ?>
    <tr>
      <td colspan="4">No data found.</td>
    </tr>
  <?php
  }
  ?>
  </tbody>
</table>
<?= $this->endSection() ?>
